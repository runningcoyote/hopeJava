import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.JFileChooser;


public class Postnet {

	public static void main(String[] args) throws FileNotFoundException {
		//creates a new JFileChooser
		JFileChooser fc = new JFileChooser( );
		//opens new dialog to allow user to select a file
        fc.showOpenDialog(null);
        //assigns fileObj as a file
        //then gets the file that is selected
        File fileObj = fc.getSelectedFile( );

		//scanner created
		Scanner s = null;
        try {
        	//file selected is run through scanner 
            s = new Scanner(fileObj);
        } catch (FileNotFoundException e) {
            System.out.println("Input file not found");
        }
        
        //creates a printWriter called output.txt
		PrintWriter pwr = new PrintWriter("output.txt");  
		String line = "";
		
		//while scanner object s has next line run the following:
		while(s.hasNextLine()) {
			line = s.nextLine();
			
			//creates an array, fields and splits by ","
			String [] fields = line.split(",");
			
			//assigning fields arrays
			String _name = fields[0];
            String _address = fields[1];
            String _city = fields[2];
            String _state = fields[3];
			String _zipcode =fields[4];
			
			//prints into output.txt
			pwr.println(_name);
            pwr.println(_address);
            pwr.println(_city+", "+_state+", "+_zipcode);
            pwr.println ( getBarCode(_zipcode) );
            pwr.println();
			
		}
		s.close();
		pwr.close();
		
	}
	public static String getBarCode (String zipcode){
		

		//digits is assigned as a string
		
		String digits= "0123456789";
		
		//Array for the postnet codes
		String [] postnet = {"||:::",":::||","::|:|", "::||:",
				":|::|", ":|:|:", ":||::", "|:::|", "|::|:",
				"|:|::"};
		
		
		
		String outPost= "";
		
		int sum = 0;
		
		for(int i = 0; i < zipcode.length(); i++) {
			//checksum %= 10;
			char c = zipcode.charAt(i);
			//the string, digits, is changed to an integer at the index of char c
			int index = digits.indexOf(c);
			//if statement for converting
			if (index > -1) {
				//converts index(digits) to their postnet match
				String postIt = postnet[index];
				
				outPost += postIt;
				//adds all the values of the index together
				sum += index;
			
			}
			
		}
		//checksum formula
		int checksum = (10- sum % 10) % 10;
		//return values
		return "|" + outPost + postnet[checksum] + "|";
		
	}

}
