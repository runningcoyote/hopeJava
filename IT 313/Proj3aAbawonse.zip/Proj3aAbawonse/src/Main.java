import java.io.*;
import java.util.Scanner;
import javax.swing.JFileChooser;
//extends Postnet???
public class Main {

	public static void main(String[] args) throws FileNotFoundException {

        // Open file containing names with FileChooser dialog
        JFileChooser fc = new JFileChooser( );
        fc.showOpenDialog(null);
        File fileObj = fc.getSelectedFile( );

        // Read names and write greetings, each in their own file.
        Scanner in = new Scanner(fileObj);
        while (in.hasNextLine( )) {
            String output = in.nextLine( );
            //String barcodeString = getBarCode(zipcode);
            
            PrintWriter pw = new PrintWriter(output + ".txt");
           // pw.println(barcodeString);
            pw.close( );
        }
        in.close( );
    }

}
